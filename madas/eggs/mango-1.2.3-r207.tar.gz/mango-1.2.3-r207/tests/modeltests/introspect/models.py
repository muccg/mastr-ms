from django.db import models


class Basic(models.Model):
    name = models.CharField(max_length=50)


class Parent(models.Model):
    pass


class Child(models.Model):
    parent = models.ForeignKey(Parent)


class OneA(models.Model):
    pass


class OneB(models.Model):
    onea = models.OneToOneField(OneA)


class ManyVia(models.Model):
    a = models.ForeignKey("ManyA")
    b = models.ForeignKey("ManyB")


class ManyA(models.Model):
    pass


class ManyB(models.Model):
    manya = models.ManyToManyField(ManyA, through=ManyVia)
