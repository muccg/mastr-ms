from django.contrib import introspect
from django.test import TestCase
from models import *


class BasicTest(TestCase):
    def setUp(self):
        self.instance = Basic.objects.create(name="Foo")

    def test_field(self):
        """
        Basic tests of the Field class.
        """
        
        model = introspect.Model(Basic)
        
        id = model.fields["id"]
        self.assertTrue(isinstance(id, introspect.Field), "Field is not a Field object")
        self.assertFalse(id.foreign_key, "id is a foreign key")
        self.assertFalse(id.many_to_many, "id is a many to many key")
        self.assertEqual(id.name, "id", "id name is incorrect")
        self.assertTrue(id.primary_key, "id is not a primary key")
        self.assertEqual(id.type, "AutoField", "id type is incorrect")
        
        name = model.fields["name"]
        self.assertTrue(isinstance(name, introspect.Field), "Field is not a Field object")
        self.assertFalse(name.foreign_key, "name is a foreign key")
        self.assertFalse(name.many_to_many, "name is a many to many key")
        self.assertEqual(name.name, "name", "name name is incorrect")
        self.assertFalse(name.primary_key, "name is a primary key")
        self.assertEqual(name.type, "CharField", "name type is incorrect")

    def test_model(self):
        """
        Really basic, fundamental tests of the Model class.
        """

        instance = introspect.Model(self.instance)
        model = introspect.Model(Basic)
        self.assertEqual(instance.model, model.model, "introspect.Model instances created from a model class and an instance of that class don't point to the same model")
        self.assertRaises(TypeError, lambda: introspect.Model(object()))

        self.assertEqual(len(model.fields), 2, "Incorrect number of fields")
        self.assertTrue("id" in model.fields, "id field does not exist")
        self.assertTrue("name" in model.fields, "name field does not exist")

        self.assertEqual(model.fields["id"], model.primary_key, "Primary key is not id")


class ForeignTest(TestCase):
    def test_foreign(self):
        child = introspect.Model(Child)

        parent = child.fields["parent"]
        self.assertTrue(isinstance(parent, introspect.Field), "Field is not a Field object")
        self.assertTrue(parent.foreign_key, "parent is not a foreign key")
        self.assertFalse(parent.many_to_many, "parent is a many to many key")
        self.assertEqual(parent.name, "parent", "parent name is incorrect")
        self.assertFalse(parent.one_to_one, "parent is a one-to-one key")
        self.assertFalse(parent.primary_key, "parent is a primary key")
        self.assertEqual(parent.to, Parent, "parent to attribute is incorrect")
        self.assertEqual(parent.type, "ForeignKey", "parent type is incorrect")


class ManyToManyTest(TestCase):
    def test_many(self):
        model = introspect.Model(ManyB)

        manya = model.fields["manya"]
        self.assertTrue(isinstance(manya, introspect.Field), "Field is not a Field object")
        self.assertFalse(manya.foreign_key, "manya is a foreign key")
        self.assertTrue(manya.many_to_many, "manya is not a many to many key")
        self.assertEqual(manya.name, "manya", "manya name is incorrect")
        self.assertFalse(manya.primary_key, "manya is a primary key")
        self.assertEqual(manya.to, ManyA, "manya to attribute is incorrect")
        self.assertEqual(manya.type, "ManyToManyField", "manya type is incorrect")
        self.assertEqual(manya.via, ManyVia, "manya via attribute is incorrect")


class OneToOneTest(TestCase):
    def test_one(self):
        model = introspect.Model(OneB)

        onea = model.fields["onea"]
        self.assertTrue(isinstance(onea, introspect.Field), "Field is not a Field object")
        self.assertTrue(onea.foreign_key, "onea is not a foreign key")
        self.assertFalse(onea.many_to_many, "onea is a many to many key")
        self.assertEqual(onea.name, "onea", "onea name is incorrect")
        self.assertTrue(onea.one_to_one, "onea is not a one-to-one key")
        self.assertFalse(onea.primary_key, "onea is a primary key")
        self.assertEqual(onea.to, OneA, "onea to attribute is incorrect")
        self.assertEqual(onea.type, "OneToOneField", "onea type is incorrect")
