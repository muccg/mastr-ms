from django import http

def index(request):
    return http.HttpResponse('')
