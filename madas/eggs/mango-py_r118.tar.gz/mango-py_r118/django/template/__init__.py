#!/usr/bin/env python

"""
New mako template system bolted into django for CCG

Code by Crispin Wellington. Need to know how this fits in, ask him.
"""

import loader
from loader import TemplateDoesNotExist
from mako.template import Template as makoTemplate
from django.conf import settings
from inspect import getargspec
from django.utils.functional import curry, Promise

_standard_context_processors = None

class Template(makoTemplate):
    def __init__(self, *args, **kwargs):
        if 'name' in kwargs:
            self._name=kwargs['name']
            del kwargs['name']
        makoTemplate.__init__(self,*args,**kwargs)

class ContextPopException(Exception):
    "pop() has been called more times than push()"
    pass

class Node(object):
    pass

class Variable(object):
    pass

class VariableNode(object):
    pass

class Context(object):
    def __init__(self, dictionary=None, autoescape=True, current_app=None):
        dictionary = dictionary or {}
        self.dicts = [dictionary]
        self.autoescape = autoescape
        self.current_app = current_app
        
    def dictify(self):
        output={}
        for d in self.dicts:
            for key in d:
                output[key]=d[key]
        return output
        
    def __repr__(self):
        return repr(self.dicts)
    
    def __iter__(self):
        for d in self.dicts:
            yield d
            
    def push(self):
        d = {}
        self.dicts = [d] + self.dicts
        return d
    
    def pop(self):
        if len(self.dicts) == 1:
            raise ContextPopException
        return self.dicts.pop(0)
    
    def __setitem__(self,key,value):
        self.dicts[0][key]=value
        
    def __getitem__(self,key):
        for d in self.dicts:
            if key in d:
                return d[key]
        raise KeyError(key)
        
    def __delitem__(self,key):
        del self.dicts[0][key]
        
    def has_key(self,key):
        for d in self.dicts:
            if key in d:
                return True
        return False
        
    __contains__ = has_key
    
    def get(self, key, otherwise=None):
        for d in self.dicts:
            if key in d:
                return d
        return otherwise
        
    def update(self, other_dict):
        if not hasattr(other_dict, '__getitem__'):
            raise TypeError('other_dict must be a mapping type object')
        self.dicts = [other_dict] + self.dicts
        return other_dict
    
# This is a function rather than module-level procedural code because we only
# want it to execute if somebody uses RequestContext.
def get_standard_processors():
    global _standard_context_processors
    if _standard_context_processors is None:
        processors = []
        for path in settings.TEMPLATE_CONTEXT_PROCESSORS:
            i = path.rfind('.')
            module, attr = path[:i], path[i+1:]
            try:
                mod = __import__(module, {}, {}, [attr])
            except ImportError, e:
                raise ImproperlyConfigured('Error importing request processor module %s: "%s"' % (module, e))
            try:
                func = getattr(mod, attr)
            except AttributeError:
                raise ImproperlyConfigured('Module "%s" does not define a "%s" callable request processor' % (module, attr))
            processors.append(func)
        _standard_context_processors = tuple(processors)
    return _standard_context_processors


class RequestContext(Context):
    def __init__(self, request, dict=None, processors=None, current_app=None):
        Context.__init__(self,dict, current_app=current_app)
        if processors is None:
            processors = ()
        else:
            processors = tuple(processors)
            
        for processor in get_standard_processors() + processors:
            self.update(processor(request))
            
        

def generic_tag_compiler(params, defaults, name, node_class, parser, token):
    "Returns a template.Node subclass."
    bits = token.split_contents()[1:]
    bmax = len(params)
    def_len = defaults and len(defaults) or 0
    bmin = bmax - def_len
    if(len(bits) < bmin or len(bits) > bmax):
        if bmin == bmax:
            message = "%s takes %s arguments" % (name, bmin)
        else:
            message = "%s takes between %s and %s arguments" % (name, bmin, bmax)
        raise TemplateSyntaxError(message)
    return node_class(bits)
    
class Library(object):
    def __init__(self):
        self.filters = {}
        self.tags = {}

    def tag(self, name=None, compile_function=None):
        if name == None and compile_function == None:
            # @register.tag()
            return self.tag_function
        elif name != None and compile_function == None:
            if(callable(name)):
                # @register.tag
                return self.tag_function(name)
            else:
                # @register.tag('somename') or @register.tag(name='somename')
                def dec(func):
                    return self.tag(name, func)
                return dec
        elif name != None and compile_function != None:
            # register.tag('somename', somefunc)
            self.tags[name] = compile_function
            return compile_function
        else:
            raise InvalidTemplateLibrary("Unsupported arguments to Library.tag: (%r, %r)", (name, compile_function))

    def tag_function(self,func):
        self.tags[getattr(func, "_decorated_function", func).__name__] = func
        return func

    def filter(self, name=None, filter_func=None):
        if name == None and filter_func == None:
            # @register.filter()
            return self.filter_function
        elif filter_func == None:
            if(callable(name)):
                # @register.filter
                return self.filter_function(name)
            else:
                # @register.filter('somename') or @register.filter(name='somename')
                def dec(func):
                    return self.filter(name, func)
                return dec
        elif name != None and filter_func != None:
            # register.filter('somename', somefunc)
            self.filters[name] = filter_func
            return filter_func
        else:
            raise InvalidTemplateLibrary("Unsupported arguments to Library.filter: (%r, %r)", (name, filter_func))

    def filter_function(self, func):
        self.filters[getattr(func, "_decorated_function", func).__name__] = func
        return func

    def simple_tag(self,func):
        
        def closure(context):
            return func()
        
        return closure
        
        params, xx, xxx, defaults = getargspec(func)

        class SimpleNode(Node):
            def __init__(self, vars_to_resolve):
                self.vars_to_resolve = map(Variable, vars_to_resolve)

            def render(self, context):
                resolved_vars = [var.resolve(context) for var in self.vars_to_resolve]
                return func(*resolved_vars)

        compile_func = curry(generic_tag_compiler, params, defaults, getattr(func, "_decorated_function", func).__name__, SimpleNode)
        compile_func.__doc__ = func.__doc__
        self.tag(getattr(func, "_decorated_function", func).__name__, compile_func)
        return func

    def inclusion_tag(self, file_name, context_class=Context, takes_context=False):
        def dec(func):
            params, xx, xxx, defaults = getargspec(func)
            if takes_context:
                if params[0] == 'context':
                    params = params[1:]
                else:
                    raise TemplateSyntaxError("Any tag function decorated with takes_context=True must have a first argument of 'context'")

            class InclusionNode(Node):
                def __init__(self, vars_to_resolve):
                    self.vars_to_resolve = map(Variable, vars_to_resolve)

                def render(self, context):
                    resolved_vars = [var.resolve(context) for var in self.vars_to_resolve]
                    if takes_context:
                        args = [context] + resolved_vars
                    else:
                        args = resolved_vars

                    dict = func(*args)

                    if not getattr(self, 'nodelist', False):
                        from django.template.loader import get_template, select_template
                        if not isinstance(file_name, basestring) and is_iterable(file_name):
                            t = select_template(file_name)
                        else:
                            t = get_template(file_name)
                        self.nodelist = t.nodelist
                    return self.nodelist.render(context_class(dict,
                            autoescape=context.autoescape))

            compile_func = curry(generic_tag_compiler, params, defaults, getattr(func, "_decorated_function", func).__name__, InclusionNode)
            compile_func.__doc__ = func.__doc__
            self.tag(getattr(func, "_decorated_function", func).__name__, compile_func)
            return func
        return dec

def get_library(module_name):
    lib = libraries.get(module_name, None)
    if not lib:
        try:
            mod = import_module(module_name)
        except ImportError, e:
            raise InvalidTemplateLibrary("Could not load template library from %s, %s" % (module_name, e))
        try:
            lib = mod.register
            libraries[module_name] = lib
        except AttributeError:
            raise InvalidTemplateLibrary("Template library %s does not have a variable named 'register'" % module_name)
    return lib
